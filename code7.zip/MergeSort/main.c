#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], temp[10], i, j, k, n, size, l1, h1, l2, h2;

    printf("Enter  number of elements:");
    scanf("%d", &n);

    printf("Enter values:\n");
    for(i = 0; i <n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Unsorted Array:\n");
    for(i = 0; i <n; i++)
    {
        printf("%d  ", array[i]);
    }

    //Logic for Merge Sort

    /*  0  1  2   3  4
        8, 3, 10, 2, 5

        size = 1
        3, 8, 2, 10, 5

        size = 2
        2, 3, 8, 10, 5

        size = 4
        2, 3, 5, 8, 10
    */

    for(size = 1; size < n; size = size * 2) // size = 1, 2, 4
    {
        l1 = 0; // 0
        k = 0; // index for temp array

        while(l1 + size < n) // 1 < 5, 3 < 5, 5 < 5, 4 < 5
        {
            h1 = l1 + size - 1; // 3
            l2 = h1 + 1; // 4
            h2 = l2 + size - 1; // 7

            //h2 exceeds the limit of the array
            if(h2 >= n)
                h2 = n - 1;// h2 = 4

            //Merge two pairs
            i = l1; // 0, 1, 2, 3, 4
            j = l2; // 4, 5

            /*
                temp[k], k = 0, 1, 2, 3, 4, 5

                3, 8, 2, 10, 5

                2, 3, 8, 10, 5

                2, 3, 5, 8, 10
            */

            while(i <= h1 && j <= h2) // 2 <= 3 && 4 <= 4
            {
                if(array[i] <= array[j]) // 8 <= 5
                    temp[k++] = array[i++];
                else
                    temp[k++] = array[j++]; //
            }

            while(i <= h1) //3 <= 3
                temp[k++] = array[i++];//
            while(j <= h2)
                temp[k++] = array[j++];

            l1 = h2 + 1; // 4
        }

        //any pair left
        for(i = l1; i < n; i++)
            temp[k++] = array[i]; // k = 5

        for(i = 0; i < n; i++)
            array[i] = temp[i];

        printf("\nSize of %d, Elements are:", size);
        for(i = 0; i < n; i++)
            printf("%d  ", array[i]);
    }

    printf("\nSorted Array:\n");
    for(i = 0; i < n; i++)
        printf("%d  ", array[i]);

    return 0;
}
