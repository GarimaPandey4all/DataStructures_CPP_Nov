#include <stdio.h>
#include <stdlib.h>

/*
    String Pre-Built Functions:

    1. String Length
    2. String Copy
    3. String Concatenation/Joining
    4. String Compare
    5. String Uppercase or LowerCase

*/

int main()
{
    char name[10];

    printf("Enter any string:");
    gets(name);

    printf("Entered String's Length is: %d", strlen(name));

    return 0;
}
