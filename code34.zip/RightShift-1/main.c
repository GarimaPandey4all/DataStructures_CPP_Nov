#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n = 24;

    printf("24 / (2 ^ 1): %d\n", (n >> 1));
    printf("24 / (2 ^ 2): %d\n", (n >> 2));

    return 0;
}
