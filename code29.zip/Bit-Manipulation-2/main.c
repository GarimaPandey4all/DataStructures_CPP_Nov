#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter any character:");
    scanf("%c", &ch);

    if((ch & 0b00100000) == 0)
        printf("Upper Case\n");

    else if((ch & 0b00100000) == 0b00100000)
        printf("Lower Case\n");

//    else
//        printf("Invalid Case");

    return 0;
}
