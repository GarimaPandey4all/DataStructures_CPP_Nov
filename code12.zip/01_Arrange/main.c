#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[] = {0, 1, 1, 0, 1, 0, 1};
    int count = 0;

    for(int i = 0; i < 7; i++)
    {
        if(arr[i] == 0)
        {
            count++;
        }
    }

    for(int i = 0; i < count; i++)
    {
        arr[i] = 0;
    }

    for(int i = count; i < 7; i++)
    {
        arr[i] = 1;
    }

    printf("Arrange Array is:\n");
    for(int i = 0; i < 7; i++)
    {
        printf("%d  ", arr[i]);
    }

    return 0;
}
