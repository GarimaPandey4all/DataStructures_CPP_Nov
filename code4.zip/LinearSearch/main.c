#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, n, search;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter elements:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    printf("\nEnter any number to be search:");
    scanf("%d", &search);

    for(i = 0; i < n; i++)
    {
        if(search == array[i])
        {
            printf("%d value found at location %d", search, i + 1);
            exit(0);
        }
    }

    if(i == n)
    {
        printf("%d value is not found", search);
    }

    return 0;
}
