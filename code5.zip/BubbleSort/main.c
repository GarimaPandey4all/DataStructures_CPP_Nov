#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, j, n, temp;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter values:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Unsorted Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    //logic for bubble sort
    for(i = 0; i < n - 1; i++)
    {
        for(j = 0; j < n - 1 - i; j++)
        {
            if(array[j] > array[j + 1])
            {
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }

    printf("\nBubble Sorted Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}
