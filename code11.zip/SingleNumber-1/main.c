#include <stdio.h>
#include <stdlib.h>

int findSingleNumber(int arr[], int n)
{
    int count = 0, i, j;

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(arr[i] == arr[j])
            count++;
        }

        if((count % 2) != 0)
        return arr[i];
    }

    return 0; // failure
}

int main()
{
    int arr[] = {1, 1, 1, 2, 2, 5, 5};

    int singleNumber = findSingleNumber(arr, 5);

    printf("Single Number is: %d", singleNumber);

    return 0;
}
