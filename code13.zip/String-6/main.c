#include <stdio.h>
#include <stdlib.h>

int main()
{
    char name[10];

    printf("Enter any string:");
    gets(name);

    printf("Lowercase String is: %s\n", strlwr(name));

    printf("Uppercase String is: %s\n", strupr(name));

    return 0;
}
