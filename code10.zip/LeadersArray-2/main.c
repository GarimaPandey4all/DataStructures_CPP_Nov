#include <stdio.h>
#include <stdlib.h>

void findLeaders(int arr[], int n)
{
    int maxElement = 0;

    for(int i = n - 1; i >= 0; i--)
    {
        if(arr[i] > maxElement)
        {
            printf("This is Leader: %d\n", arr[i]);
            maxElement = arr[i];
        }
    }
}

int main()
{
    int arr[] = {16, 19, 4, 7, 3};

    findLeaders(arr, 5);

    return 0;
}
