#include <stdio.h>
#include <stdlib.h>

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return (n);
};

//insert at start position only once
void insertAtStart()
{
    struct node *temp;

    if(START == NULL)
    {
        temp = createNode();

        temp->prev = NULL;

        printf("Enter any number:");
        scanf("%d", &temp->info);

        temp->next = START;

        START = temp;
    }

    else
    {
        printf("List has some nodes");
    }
}


int main()
{

    return 0;
}
