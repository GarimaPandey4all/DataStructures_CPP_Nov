#include <stdio.h>
#include <stdlib.h>

int findSingleNumber(int arr[], int n)
{
    int result = 0;

    for(int i = 0; i < n; i++)
    {
        result ^= arr[i]; // result = result ^ arr[i];
    }

    return result;
}

int main()
{
    int arr[] = {3, 3, 2, 2, 7, 7, 7};

    int singleNumber = findSingleNumber(arr, 7);

    printf("Single Number is: %d", singleNumber);

    return 0;
}
