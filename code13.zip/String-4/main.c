#include <stdio.h>
#include <stdlib.h>

int main()
{
    char firstName[10];
    char lastName[10];

    printf("Enter String-1:");
    gets(firstName);

    printf("Enter String-2:");
    gets(lastName);

    printf("Your Fullname is: %s", strcat(firstName, lastName));


    return 0;
}
