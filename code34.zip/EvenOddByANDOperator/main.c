#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any number for a and b:");
    scanf("%d %d", &a, &b);

    if(a & 1)
        printf("%d is an Odd Number\n", a);
    else
        printf("%d is an Even Number\n", a);


    if(b & 1)
        printf("%d is an Odd Number\n", b);
    else
        printf("%d is an Even Number\n", b);

    return 0;
}
