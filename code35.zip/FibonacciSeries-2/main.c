#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n)
{
    int F[n + 1];

    F[0] = 0;
    F[1] = 1;

    for(int i = 2; i <= n; i++)
    {
        F[i] = F[i - 1] + F[i - 2];
    }

    return F[n];
}

int main()
{
    int n = 5, result;

    result = fibonacci(n - 1);

    printf("Fibonacci Series is:%d", result);

    return 0;
}
