#include <stdio.h>
#include <stdlib.h>

int main()
{
    int marks[5], i, sum = 0, percentage;

    printf("Enter your marks:");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &marks[i]);
    }

    for(i = 0; i < 5; i++)
    {
        sum += marks[i]; // sum = sum + marks[i];
    }

    printf("Sum is: %d\n", sum);

    percentage = sum / 5; // (sum / 500) * 100

    printf("Percentage is: %d\n", percentage);

    if(percentage >= 50 && percentage <= 60)
    {
        printf("Grade D");
    }
    else if(percentage >= 60 && percentage <= 70)
        printf("Grade C");
    else if(percentage >= 70 && percentage <= 80)
        printf("Grade B");
    else if(percentage >= 80 && percentage <= 100)
        printf("Grade A");
    else
        printf("Fail...");

    return 0;
}
