#include <stdio.h>
#include <stdlib.h>

void findLeaders(int arr[], int n)
{
    int j;

    for(int i = 0; i < n; i++)
    {
        for(j = i + 1; j < n; j++)
        {
            if(arr[i] <= arr[j])
            {
                break;
            }
        }

        if(j == n)
            printf("This is Leader: %d\n", arr[i]);
    }
}

int main()
{
    int arr[] = {16, 19, 4, 7, 3};

    findLeaders(arr, 5);

    return 0;
}
