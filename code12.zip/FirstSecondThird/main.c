#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[] = {2, 13, 4, 1, 3, 6, 28};

    int first = arr[0];

    int second, third;

    second = third = 0;

    for(int i = 0; i < 7; i++)
    {
        if(arr[i] > first)
        {
            third = second;
            second = first;
            first = arr[i];
        }

        else if(arr[i] > second)
        {
            third = second;
            second = arr[i];
        }

        else if(arr[i] > third)
        {
            third = arr[i];
        }
    }

    printf("First Largest is: %d\n", first);
    printf("Second Largest is: %d\n", second);
    printf("Third Largest is: %d\n", third);

    return 0;
}
