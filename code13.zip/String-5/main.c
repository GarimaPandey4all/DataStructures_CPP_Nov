#include <stdio.h>
#include <stdlib.h>

/*
    strcmp(str1, str2); = 0, 1, -1.........

    str1 = a
    str2 = a

    str1 = a
    str2 = b

    str1 = b
    str2 = a
*/

int main()
{
    char firstName[10];
    char lastName[10];

    printf("Enter String-1:");
    gets(firstName);

    printf("Enter String-2:");
    gets(lastName);

    if(strcmp(str1, str2) == 0)
    {
        printf("Same Strings");
    }
    else
    {
        printf("Not the Same Strings");
    }

    return 0;
}
