#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;

    x = func(3); // function calling

    printf("%d", x);

    return 0;
}

int func(int a)
{
    int sum;

    if(a == 1) // base condition - stop condition
        return a;
    sum = a + func(a - 1); // recursive call

    return sum;
}
