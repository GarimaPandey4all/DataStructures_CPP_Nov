#include <iostream>

using namespace std;

int main()
{
    printf("Lowercase: %c\n", ('R' | ' '));
    printf("Lowercase: %c\n", ('r' | ' '));
    printf("Uppercase: %c\n", ('i' & '_'));
    printf("Uppercase: %c\n", ('I' & '_'));

    return 0;
}
