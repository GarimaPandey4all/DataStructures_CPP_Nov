#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("AND Operator:%d\n", (a & b));
    printf("OR Operator:%d\n", (a | b));
    printf("X-OR Operator:%d\n", (a^ b));
    printf("Left Shift Operator:%d\n", (a<<2));
    printf("Right Shift Operator:%d\n", (a>>2));

    return 0;
}
