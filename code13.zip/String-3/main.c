#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter String-1:");
    gets(str1);

    printf("Enter String-2:");
    gets(str2);

    //printf("String-1 Copying to String-2: %s", strcpy(str1, str2));
    printf("String-1 Copying to String-2: %s", strcpy(str1, "Pune"));

    return 0;
}
