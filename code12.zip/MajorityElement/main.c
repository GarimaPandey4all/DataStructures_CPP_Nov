#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int arr[] = {2, 2, 1, 1, 1, 2, 2};
    int arr[] = {3, 2, 3};

    int majorityElement = findMajorityElement(arr, 3);

    printf("Majority Element is: %d", majorityElement);

    return 0;
}

int findMajorityElement(int arr[], int n)
{
    int m = 0, cnt = 0;

    for(int i = 0; i<n; i++)
    {
        if(cnt == 0)
        {
            m = arr[i];
            cnt = cnt + 1;
        }

        else
        {
            if(m == arr[i])
            {
                cnt++;
            }
            else
            {
                cnt--;
            }
        }
    }

    cnt = 0; //reassign

    for(int i = 0; i < n; i++)
    {
        if(m == arr[i])
        {
            cnt++;
        }

        if(cnt > n/2)
        {
            return m;
        }
    }

    return 0; // failure
}
