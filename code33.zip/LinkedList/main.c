#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *link;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return (n);
};

void insertNode()
{
    struct node *temp, *t;

    temp = createNode();

    printf("Enter any number:");
    scanf("%d", &temp->info);

    temp->link = NULL;

    if(START == NULL)
    {
        START = temp;
    }
    else
    {
        t = START;

        while(t->link != NULL)
        {
            t = t->link;
        }

        t->link = temp;
    }
}

void deleteNode()
{
    struct node *t;

    if(START == NULL)
        printf("List is Empty");
    else
    {
        t = START;

        START = START->link;

        free(t);
    }
}

void viewList()
{
    struct node *t;

    if(START == NULL)
        printf("List is Empty");
    else
    {
        t = START;

        while(t != NULL)
        {
            printf("%d  ", t->info);
            t = t->link;
        }
    }
}

void searchList()
{
    struct node *t;
    int search;

    if(START != NULL)
    {
        t = START;

        printf("Enter any number to be search:");
        scanf("%d", &search);

        while(t != NULL)
        {
            if(t->info == search)
            {
                printf("%d search value is found.", search);
            }
            t = t->link;
        }
    }

    else
    {
        printf("List is Empty. Invalid Search");
    }
}

//void reverseList()
//{
//    struct node *prevNode, *curNode;
//
//    if(START != NULL)
//    {
//        prevNode = START;
//        curNode = START->link;
//        START = START->link;
//
//        prevNode->link = NULL; // make first node as last node
//
//        while(START != NULL)
//        {
//            START = START->link;
//            curNode->link = prevNode;
//
//            prevNode = curNode;
//            curNode = START;
//        }
//
//        START = prevNode;
//
//        printf("Successfully Reversed List");
//
//    }
//}

struct node *reverseLinkedList(struct node *START)
{
    struct node *newHead = NULL;

    while(START != NULL)
    {
        struct node *temp = START->link;
        START->link = newHead;
        newHead = START;
        START = temp;
    }

    return newHead;

};

int isPalindrome()
{
    if(START == NULL)
    {
        printf("Palindrome Linked List");
        return 1;
    }

    struct node *slow = START;
    struct node *fast = START;

    while(fast->link != NULL && fast->link->link != NULL)
    {
        fast = fast->link->link;
        slow = slow->link;
    }

    struct node *firstHalfHead = START;
    struct node *secondHalfHead = reverseLinkedList(slow->link);

    while(firstHalfHead != NULL && secondHalfHead != NULL)
    {
        if(firstHalfHead->info != secondHalfHead->info)
        {
            printf("Not a Palindrome Linked List");
            return 0;
        }

        firstHalfHead = firstHalfHead->link;
        secondHalfHead = secondHalfHead->link;
    }

    printf("Palindrome Linked List");
    return 1;
}

int main()
{
    int choice;

    while(1)
    {
    printf("\n1. Insert");
    printf("\n2. Delete");
    printf("\n3. ViewList");
    printf("\n4. SearchList");
    printf("\n5. Exit");
    printf("\n6. Palindrome Linked List");
    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        insertNode();
        break;

    case 2:
        deleteNode();
        break;

    case 3:
        viewList();
        break;

    case 4:
        searchList();
        break;

    case 5:
        exit(0);

    case 6:
        isPalindrome();
        break;

    default:
        printf("Invalid Choice");

    }
}
    return 0;
}
