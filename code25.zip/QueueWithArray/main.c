#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

int item[SIZE], front = -1, rear = -1;

void enqueue() // insertion
{
    int value;

    if(rear == SIZE-1)
    {
        printf("Queue is full");
    }
    else
    {
        printf("Enter any value:");
        scanf("%d", &value);

        if(front == -1)
            front = 0;

        rear++;
        item[rear] = value;
    }
}

void dequeue()
{
    if(front == -1)
    {
        printf("Queue is empty");
    }
    else
    {
        printf("Deleted value is: %d", item[front]);
        front++;

        if(front > rear)
        {
            front = rear = -1;
        }
    }
}

void display()
{
    if(rear == -1)
    {
        printf("Queue is empty");
    }
    else
    {
        int i;
        printf("Elements in queue are:\n");
        for(i = front; i <= rear; i++)
        {
            printf("%d  ", item[i]);
        }
    }
}

int main()
{
     int choice;

    while(1)
    {
        printf("\n\n1. Insert");
        printf("\n2. Delete");
        printf("\n3. Display");
        printf("\n4. Exit");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            enqueue();
            break;

        case 2:
            dequeue();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice");
        }
    }

    return 0;
}
