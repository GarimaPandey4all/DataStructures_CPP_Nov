#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12

//const int MONTHS = 12;

int main()
{
    int i;
    int days[MONTHS] = {31, 29, 30, 31, 30, 31, 30, 31, 30, 31, 30, 31};

    for(i = 0; i < MONTHS; i++)
    {
        printf("%d month has %d days.\n", i + 1, days[i]);
        //%d - Format Specifier
    }

    return 0;
}
