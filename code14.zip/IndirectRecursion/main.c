#include <stdio.h>
#include <stdlib.h>

void funcB(int n)
{
    if(n > 1)
    {
        printf("%d\n", n);
        funcA(n / 2);
    }
}

void funcA(int n)
{
    if(n > 0)
    {
        printf("%d\n", n);
        funcB(n - 1);
    }
}

int main()
{
    funcA(3);

    return 0;
}
