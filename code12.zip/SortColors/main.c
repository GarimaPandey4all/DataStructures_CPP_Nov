#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[] = {2, 0, 1};

    sortColors(arr, 3);

    for(int i = 0; i < 3; i++)
    {
        printf("%d  ", arr[i]);
    }

    return 0;
}

void sortColors(int arr[], int n)
{
    int c, l, h;

    int temp;

    c = l = 0;

    h = n - 1;

    while(c <= h)
    {
        if(arr[c] == 0)
        {
            temp = arr[c];
            arr[c] = arr[l];
            arr[l] = temp;
            c++;
            l++;
        }

        else if(arr[c] == 1)
        {
            c++;
        }

        else if(arr[c] == 2)
        {
            temp = arr[c];
            arr[c] = arr[h];
            arr[h] = temp;
            h--;
        }
    }
}
