#include <stdio.h>
#include <stdlib.h>

int lis(int arr[], int n)
{
    int lis[n];

    lis[0] = 1;

    for(int i = 1; i < n; i++)
    {
        lis[i] = 1;

        for(int j = 0; j < i; j++)
        {
            if(arr[i] > arr[j] && lis[i] < lis[j] + 1) // lis[1] = 1 , lis[0] + 1 = 1 + 1
            {
                lis[i] = lis[j] + 1;
            }
        }
    }

    return max_element(lis, n);
}

int max_element(int arr[], int n)
{
    for(int i = 1; i < n; i++)
    {
        if(arr[0] < arr[i])
            arr[0] = arr[i];
    }
    return arr[0];
}

int main()
{
    int arr[] = {10, 22, 9, 33, 21, 50, 41};
    int n = sizeof(arr) / sizeof(arr[0]);

    int result = lis(arr, n);

    printf("Length of the LIS is: %d", result);

    return 0;
}
