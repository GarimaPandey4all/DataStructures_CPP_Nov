#include <stdio.h>
#include <stdlib.h>
#define SIZE 10

int arr[SIZE];
int top1 = -1;
int top2 = SIZE;

void pushStack_1(int data)
{
    if(top1 < top2 - 1)
    {
        arr[++top1] = data;
    }
    else
    {
        printf("Stack-1 Overflow\n");
    }
}

void pushStack_2(int data)
{
    if(top1 < top2 - 1)
    {
        arr[--top2] = data;
    }
    else
    {
        printf("Stack-2 Overflow\n");
    }
}

void popStack_1()
{
    if(top1 >= 0)
    {
        int popValue = arr[top1--];
        printf("%d is popped value from stack-1\n", popValue);
    }
    else
    {
        printf("Stack-1 Underflow");
    }
}

void popStack_2()
{
    if(top2 < SIZE)
    {
        int popValue = arr[top2++];
        printf("%d is popped value from stack-2\n", popValue);
    }
    else
    {
        printf("Stack-2 Underflow");
    }
}


void displayStack_1()
{
    int i;
    for(i = top1; i >= 0; i--)
    {
        printf("%d  ", arr[i]);
    }
    printf("\n");
}

void displayStack_2()
{
    int i;
    for(i = top2; i < SIZE; i++)
    {
        printf("%d  ", arr[i]);
    }
    printf("\n");
}

int main()
{
    int i;

    for(i = 1; i <= 5; i++)
    {
        pushStack_1(i);
        printf("Value pushed into a stack-1 is: %d\n", i);
    }


    for(i = 1; i <= 5; i++)
    {
        pushStack_2(i);
        printf("Value pushed into a stack-2 is: %d\n", i);
    }

    displayStack_1();
    displayStack_2();

    popStack_1();
    popStack_2();

    displayStack_1();
    displayStack_2();

    return 0;
}
